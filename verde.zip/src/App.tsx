import { Layout } from './layouts';

function App() {
  return <Layout />;
}

export default App;
